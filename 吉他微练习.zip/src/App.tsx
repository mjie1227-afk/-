import React, { useState, useEffect } from 'react';
import { Play, CheckCircle2, BookOpen, Calendar, Clock, Plus, X, Check, Shuffle, Sparkles, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { exercises } from './data/exercises';
import { DailyLog, Exercise } from './types';
import { cn } from './lib/utils';
import { GoogleGenAI, Type } from '@google/genai';

const TODAY = new Date().toISOString().split('T')[0];

export default function App() {
  const [activeTab, setActiveTab] = useState<'today' | 'library' | 'history' | 'coach'>('today');
  const [logs, setLogs] = useState<DailyLog[]>([]);
  const [customExercises, setCustomExercises] = useState<Exercise[]>([]);
  const [activeTimer, setActiveTimer] = useState<string | null>(null);
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes in seconds
  const [timerRunning, setTimerRunning] = useState(false);

  // AI Coach State
  const [bottleneck, setBottleneck] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [coachMessage, setCoachMessage] = useState('');
  const [generatedExercises, setGeneratedExercises] = useState<Exercise[]>([]);
  const [showGeneratedModal, setShowGeneratedModal] = useState(false);
  const [activeSlide, setActiveSlide] = useState(0);

  // Load logs and custom exercises from local storage
  useEffect(() => {
    const savedLogs = localStorage.getItem('guitar-logs');
    if (savedLogs) {
      setLogs(JSON.parse(savedLogs));
    } else {
      // Initialize today's log if empty
      setLogs([{
        date: TODAY,
        selectedExercises: [],
        feedback: '',
        adjustments: ''
      }]);
    }

    const savedCustom = localStorage.getItem('guitar-custom-exercises');
    if (savedCustom) {
      setCustomExercises(JSON.parse(savedCustom));
    }
  }, []);

  // Save logs to local storage
  useEffect(() => {
    if (logs.length > 0) {
      localStorage.setItem('guitar-logs', JSON.stringify(logs));
    }
  }, [logs]);

  // Save custom exercises to local storage
  useEffect(() => {
    if (customExercises.length > 0) {
      localStorage.setItem('guitar-custom-exercises', JSON.stringify(customExercises));
    }
  }, [customExercises]);

  const allExercises = [...exercises, ...customExercises];

  // Timer logic
  useEffect(() => {
    let interval: number;
    if (timerRunning && timeLeft > 0) {
      interval = window.setInterval(() => {
        setTimeLeft((prev) => prev - 1);
      }, 1000);
    } else if (timeLeft === 0 && timerRunning) {
      setTimerRunning(false);
      // Mark as completed
      if (activeTimer) {
        toggleExerciseCompletion(activeTimer, true);
      }
    }
    return () => clearInterval(interval);
  }, [timerRunning, timeLeft, activeTimer]);

  const todayLog = logs.find(l => l.date === TODAY) || {
    date: TODAY,
    selectedExercises: [],
    feedback: '',
    adjustments: ''
  };

  const updateTodayLog = (updates: Partial<DailyLog>) => {
    setLogs(prev => {
      const existing = prev.find(l => l.date === TODAY);
      if (existing) {
        return prev.map(l => l.date === TODAY ? { ...l, ...updates } : l);
      }
      return [...prev, { date: TODAY, selectedExercises: [], feedback: '', adjustments: '', ...updates }];
    });
  };

  const addExerciseToToday = (exerciseId: string) => {
    if (todayLog.selectedExercises.length >= 2) {
      alert('每天最多选择 2 个微练习，保持专注！');
      return;
    }
    if (todayLog.selectedExercises.find(e => e.exerciseId === exerciseId)) {
      return;
    }
    updateTodayLog({
      selectedExercises: [...todayLog.selectedExercises, { exerciseId, completed: false }]
    });
    setActiveTab('today');
  };

  const removeExerciseFromToday = (exerciseId: string) => {
    updateTodayLog({
      selectedExercises: todayLog.selectedExercises.filter(e => e.exerciseId !== exerciseId)
    });
  };

  const toggleExerciseCompletion = (exerciseId: string, completed?: boolean) => {
    updateTodayLog({
      selectedExercises: todayLog.selectedExercises.map(e => 
        e.exerciseId === exerciseId 
          ? { ...e, completed: completed !== undefined ? completed : !e.completed } 
          : e
      )
    });
  };

  const handleRandomDraw = () => {
    // Pick 1 from Tech/Change (A or C) and 1 from Theory/Rep (B or D)
    const techExercises = allExercises.filter(e => e.category === 'A' || e.category === 'C');
    const theoryExercises = allExercises.filter(e => e.category === 'B' || e.category === 'D');

    const randomTech = techExercises[Math.floor(Math.random() * techExercises.length)];
    const randomTheory = theoryExercises[Math.floor(Math.random() * theoryExercises.length)];

    updateTodayLog({
      selectedExercises: [
        { exerciseId: randomTech.id, completed: false },
        { exerciseId: randomTheory.id, completed: false }
      ]
    });
    setActiveTab('today');
  };

  const handleGenerateExercises = async () => {
    if (!bottleneck.trim()) return;
    setIsGenerating(true);
    setCoachMessage('');
    setGeneratedExercises([]);
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `用户目前的练习瓶颈或目标是：“${bottleneck}”。请你根据这个瓶颈，为他定制 2 个极度聚焦、具有针对性的【5分钟原子微练习】。`,
        config: {
          systemInstruction: `你是一位资深吉他教练，擅长将复杂的练习拆解为“原子化”的微习惯。不仅懂技术，更像一位文学阅读专家一样，擅长引导学生去感受乐谱的呼吸感和表达。
你的服务对象是一名学了一年木吉他的初学者（懂基础乐理，有横按基础但不熟练，拨片零基础）。
具体要求：
1. 其中一个练习侧重于纯机能/节奏 (分类必须为 'A' 或 'C')。
2. 另一个练习侧重于应用/乐理/表达 (分类必须为 'B' 或 'D')。
3. 目标必须高度具体、可量化执行，绝对能在这 5 分钟内完成。
4. 语气要专业且充满鼓励。
请返回 JSON 格式，包含 coachMessage（教练的鼓励和分析，支持换行）和 exercises（包含2个练习的数组）。`,
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              coachMessage: { type: Type.STRING, description: "教练的鼓励和分析" },
              exercises: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    title: { type: Type.STRING },
                    description: { type: Type.STRING },
                    steps: { type: Type.ARRAY, items: { type: Type.STRING } },
                    category: { type: Type.STRING, enum: ["A", "B", "C", "D"] },
                    categoryLabel: { type: Type.STRING, description: "例如：A. 纯机能与拨片 (Tech)" },
                    target: { type: Type.STRING, description: "具体可量化的目标" }
                  },
                  required: ["title", "description", "steps", "category", "categoryLabel", "target"]
                }
              }
            },
            required: ["coachMessage", "exercises"]
          }
        }
      });

      if (response.text) {
        const data = JSON.parse(response.text);
        setCoachMessage(data.coachMessage);
        
        const newExercises = data.exercises.map((ex: any) => ({
          ...ex,
          id: `ai-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`
        }));
        
        setGeneratedExercises(newExercises);
        setCustomExercises(prev => [...prev, ...newExercises]);
        setShowGeneratedModal(true);
        setActiveSlide(0);
      }
    } catch (error) {
      console.error(error);
      setCoachMessage("抱歉，教练现在有点忙，请稍后再试。");
    } finally {
      setIsGenerating(false);
    }
  };

  const startTimer = (exerciseId: string) => {
    setActiveTimer(exerciseId);
    setTimeLeft(300);
    setTimerRunning(true);
  };

  const closeTimer = () => {
    setActiveTimer(null);
    setTimerRunning(false);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  const NavItems = () => (
    <>
      <button onClick={() => setActiveTab('today')} className={cn("flex items-center gap-3 px-4 py-3 rounded-xl transition-colors w-full", activeTab === 'today' ? "bg-[var(--color-spruce)]/10 text-[var(--color-spruce)]" : "text-[var(--color-text-muted)] hover:text-[var(--color-text-main)] hover:bg-white/5")}>
        <Clock size={20} /> <span className="font-medium">今日目标</span>
      </button>
      <button onClick={() => setActiveTab('library')} className={cn("flex items-center gap-3 px-4 py-3 rounded-xl transition-colors w-full", activeTab === 'library' ? "bg-[var(--color-spruce)]/10 text-[var(--color-spruce)]" : "text-[var(--color-text-muted)] hover:text-[var(--color-text-main)] hover:bg-white/5")}>
        <BookOpen size={20} /> <span className="font-medium">练习库</span>
      </button>
      <button onClick={() => setActiveTab('coach')} className={cn("flex items-center gap-3 px-4 py-3 rounded-xl transition-colors w-full", activeTab === 'coach' ? "bg-[var(--color-spruce)]/10 text-[var(--color-spruce)]" : "text-[var(--color-text-muted)] hover:text-[var(--color-text-main)] hover:bg-white/5")}>
        <Sparkles size={20} /> <span className="font-medium">AI 教练</span>
      </button>
      <button onClick={() => setActiveTab('history')} className={cn("flex items-center gap-3 px-4 py-3 rounded-xl transition-colors w-full", activeTab === 'history' ? "bg-[var(--color-spruce)]/10 text-[var(--color-spruce)]" : "text-[var(--color-text-muted)] hover:text-[var(--color-text-main)] hover:bg-white/5")}>
        <Calendar size={20} /> <span className="font-medium">打卡回顾</span>
      </button>
    </>
  );

  return (
    <div className="min-h-screen flex flex-col md:flex-row max-w-[1600px] mx-auto relative">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 lg:w-72 border-r border-white/5 p-6 h-screen sticky top-0 shrink-0">
        <div className="mb-12 mt-4 px-4">
          <h1 className="text-3xl font-serif font-semibold text-[var(--color-spruce)] drop-shadow-md">
            吉他微练习
          </h1>
          <p className="text-xs text-[var(--color-text-muted)] mt-2 font-medium tracking-wider uppercase">
            {new Date().toLocaleDateString('zh-CN', { month: 'long', day: 'numeric', weekday: 'long' })}
          </p>
        </div>
        <nav className="flex flex-col gap-2">
          <NavItems />
        </nav>
      </aside>

      {/* Mobile Header */}
      <header className="md:hidden pt-12 pb-6 px-6 relative z-10">
        <h1 className="text-3xl font-serif font-semibold text-[var(--color-spruce)] drop-shadow-md">
          吉他微练习
        </h1>
        <p className="text-sm text-[var(--color-text-muted)] mt-1 font-medium tracking-wider uppercase">
          {new Date().toLocaleDateString('zh-CN', { month: 'long', day: 'numeric', weekday: 'long' })}
        </p>
      </header>

      {/* Main Content */}
      <main className="flex-1 px-6 md:px-12 pt-2 md:pt-12 pb-24 md:pb-12 overflow-y-auto h-screen">
        <AnimatePresence mode="wait">
          {activeTab === 'today' && (
            <motion.div
              key="today"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="grid grid-cols-1 lg:grid-cols-2 gap-8"
            >
              <section className="space-y-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-xl font-serif font-semibold text-[var(--color-text-main)]">今日目标 (5分钟)</h2>
                  <span className="text-xs font-medium px-2 py-1 bg-[var(--color-wood-light)] text-[var(--color-spruce)] rounded-full border border-[var(--color-spruce-dim)] border-opacity-30">
                    {todayLog.selectedExercises.filter(e => e.completed).length} / {todayLog.selectedExercises.length}
                  </span>
                </div>
                
                {todayLog.selectedExercises.length === 0 ? (
                  <div className="glass-card rounded-2xl p-8 text-center border-dashed border-[var(--color-spruce-dim)] opacity-90">
                    <p className="text-sm text-[var(--color-text-muted)] mb-6">今天还没有选择练习</p>
                    <div className="flex flex-col gap-3">
                      <button 
                        onClick={handleRandomDraw}
                        className="w-full py-3 bg-[var(--color-spruce)] text-[var(--color-bg-deep)] rounded-xl text-sm font-semibold hover:bg-opacity-90 transition-all flex items-center justify-center gap-2 shadow-lg shadow-[var(--color-spruce)]/20"
                      >
                        <Shuffle size={18} /> 智能抽取 (1机能 + 1表达)
                      </button>
                      <button 
                        onClick={() => setActiveTab('library')}
                        className="w-full py-3 bg-[var(--color-wood-light)] text-[var(--color-text-main)] rounded-xl text-sm font-medium hover:bg-opacity-80 transition-all"
                      >
                        去练习库挑选
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {todayLog.selectedExercises.map((item) => {
                      const ex = allExercises.find(e => e.id === item.exerciseId);
                      if (!ex) return null;
                      return (
                        <div 
                          key={item.exerciseId}
                          className={cn(
                            "glass-card rounded-2xl p-5 transition-all border-l-4",
                            item.completed ? "border-green-500/80 opacity-60" : "border-[var(--color-spruce)]"
                          )}
                        >
                          <div className="flex justify-between items-start mb-2">
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-bold tracking-wider uppercase text-[var(--color-spruce)] bg-[var(--color-wood-light)] px-2 py-1 rounded-md">
                                {ex.categoryLabel}
                              </span>
                            </div>
                            <button onClick={() => removeExerciseFromToday(ex.id)} className="text-[var(--color-text-muted)] hover:text-red-400">
                              <X size={16} />
                            </button>
                          </div>
                          <h3 className="font-serif font-semibold text-lg leading-tight mb-1 text-[var(--color-text-main)]">{ex.title}</h3>
                          <p className="text-xs text-[var(--color-text-muted)] mb-4 line-clamp-2">{ex.target}</p>
                          
                          <div className="flex items-center gap-3">
                            <button
                              onClick={() => toggleExerciseCompletion(ex.id)}
                              className={cn(
                                "flex-1 py-2 rounded-xl text-sm font-medium flex items-center justify-center gap-2 transition-colors",
                                item.completed 
                                  ? "bg-green-900/30 text-green-400 border border-green-500/30" 
                                  : "bg-[var(--color-wood-light)] text-[var(--color-text-main)] hover:bg-opacity-80"
                              )}
                            >
                              <CheckCircle2 size={16} />
                              {item.completed ? '已完成' : '标记完成'}
                            </button>
                            {!item.completed && (
                              <button
                                onClick={() => startTimer(ex.id)}
                                className="flex-1 py-2 bg-[var(--color-spruce)] text-[var(--color-bg-deep)] rounded-xl text-sm font-semibold flex items-center justify-center gap-2 hover:bg-opacity-90 transition-colors shadow-lg shadow-[var(--color-spruce)]/20"
                              >
                                <Play size={16} fill="currentColor" />
                                开始 5 分钟
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                    
                    {todayLog.selectedExercises.length < 2 && (
                       <button 
                         onClick={() => setActiveTab('library')}
                         className="w-full py-4 border-2 border-dashed border-[var(--color-spruce-dim)] text-[var(--color-spruce-dim)] rounded-2xl flex items-center justify-center gap-2 text-sm font-medium hover:bg-[var(--color-wood-light)] hover:text-[var(--color-spruce)] transition-colors opacity-60 hover:opacity-100"
                       >
                         <Plus size={18} /> 添加第二个微练习
                       </button>
                    )}
                  </div>
                )}
              </section>

              <section className="glass-card rounded-3xl p-6">
                <h2 className="text-xl font-serif font-semibold mb-4 flex items-center gap-2 text-[var(--color-text-main)]">
                  <span className="text-2xl">🏆</span> 今日即时反馈
                </h2>
                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-semibold text-[var(--color-spruce-dim)] uppercase tracking-wider mb-2">
                      今天我做到了
                    </label>
                    <textarea 
                      value={todayLog.feedback}
                      onChange={(e) => updateTodayLog({ feedback: e.target.value })}
                      placeholder="写下你今天切实感受到的微小进步，给大脑提供多巴胺奖励！"
                      className="w-full bg-[var(--color-wood-dark)] text-[var(--color-text-main)] placeholder-[var(--color-text-muted)] rounded-xl p-3 text-sm border border-white/5 focus:ring-1 focus:ring-[var(--color-spruce)] resize-none h-24 outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[var(--color-spruce-dim)] uppercase tracking-wider mb-2">
                      遇到的问题 / 明日微调方向
                    </label>
                    <textarea 
                      value={todayLog.adjustments}
                      onChange={(e) => updateTodayLog({ adjustments: e.target.value })}
                      placeholder="例如：食指还是有点僵硬，明天尝试再放松一点。"
                      className="w-full bg-[var(--color-wood-dark)] text-[var(--color-text-main)] placeholder-[var(--color-text-muted)] rounded-xl p-3 text-sm border border-white/5 focus:ring-1 focus:ring-[var(--color-spruce)] resize-none h-20 outline-none"
                    />
                  </div>
                </div>
              </section>
            </motion.div>
          )}

          {activeTab === 'library' && (
            <motion.div
              key="library"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div className="flex justify-between items-end mb-2">
                <div>
                  <h2 className="text-xl font-serif font-semibold text-[var(--color-text-main)]">练习库</h2>
                  <p className="text-xs text-[var(--color-text-muted)] mt-1">建议每天搭配：1个机能 + 1个表达</p>
                </div>
                <button 
                  onClick={handleRandomDraw}
                  className="px-3 py-1.5 bg-[var(--color-wood-light)] text-[var(--color-spruce)] rounded-lg text-xs font-medium flex items-center gap-1 border border-[var(--color-spruce-dim)] border-opacity-30 hover:bg-[var(--color-spruce)] hover:text-[var(--color-bg-deep)] transition-colors"
                >
                  <Shuffle size={14} /> 智能抽取
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {allExercises.map(ex => {
                  const isSelected = todayLog.selectedExercises.some(e => e.exerciseId === ex.id);
                  return (
                    <div key={ex.id} className="glass-card rounded-2xl p-5">
                      <div className="flex justify-between items-start mb-2">
                        <span className="text-[10px] font-bold tracking-wider uppercase text-[var(--color-spruce)] bg-[var(--color-wood-light)] px-2 py-1 rounded-md">
                          {ex.categoryLabel}
                        </span>
                        <button
                          onClick={() => isSelected ? removeExerciseFromToday(ex.id) : addExerciseToToday(ex.id)}
                          className={cn(
                            "w-8 h-8 rounded-full flex items-center justify-center transition-colors border",
                            isSelected 
                              ? "bg-green-900/30 text-green-400 border-green-500/30" 
                              : "bg-[var(--color-wood-dark)] text-[var(--color-text-main)] border-white/10 hover:border-[var(--color-spruce)] hover:text-[var(--color-spruce)]"
                          )}
                        >
                          {isSelected ? <Check size={16} /> : <Plus size={16} />}
                        </button>
                      </div>
                      <h3 className="font-serif font-semibold text-lg leading-tight mb-2 text-[var(--color-text-main)]">{ex.title}</h3>
                      <p className="text-xs text-[var(--color-text-muted)] mb-3">{ex.description}</p>
                      
                      <div className="bg-[var(--color-wood-dark)] p-3 rounded-xl border border-white/5">
                        <p className="text-[11px] font-semibold text-[var(--color-spruce-dim)] mb-1">🎯 目标：</p>
                        <p className="text-[11px] text-[var(--color-text-muted)]">{ex.target}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          )}

          {activeTab === 'coach' && (
            <motion.div
              key="coach"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <div>
                <h2 className="text-xl font-serif font-semibold text-[var(--color-text-main)]">AI 教练</h2>
                <p className="text-xs text-[var(--color-text-muted)] mt-1">告诉我你现在的瓶颈，我为你定制微练习</p>
              </div>

              <div className="glass-card rounded-3xl p-6 space-y-4 max-w-3xl">
                <textarea 
                  value={bottleneck}
                  onChange={(e) => setBottleneck(e.target.value)}
                  placeholder="例如：F和弦横按总是按不响，或者右手扫弦节奏不稳..."
                  className="w-full bg-[var(--color-wood-dark)] text-[var(--color-text-main)] placeholder-[var(--color-text-muted)] rounded-xl p-4 text-sm border border-white/5 focus:ring-1 focus:ring-[var(--color-spruce)] resize-none h-28 outline-none"
                />
                <button 
                  onClick={handleGenerateExercises}
                  disabled={isGenerating || !bottleneck.trim()}
                  className="w-full py-3 bg-[var(--color-spruce)] text-[var(--color-bg-deep)] rounded-xl text-sm font-semibold hover:bg-opacity-90 transition-all flex items-center justify-center gap-2 shadow-lg shadow-[var(--color-spruce)]/20 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isGenerating ? <Loader2 size={18} className="animate-spin" /> : <Sparkles size={18} />}
                  {isGenerating ? '教练正在思考...' : '定制微练习'}
                </button>
              </div>

              {coachMessage && (
                <motion.div 
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="glass-card rounded-3xl p-6 border-l-4 border-l-[var(--color-spruce)] max-w-3xl"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-[var(--color-wood-light)] flex items-center justify-center shrink-0">
                      <Sparkles size={16} className="text-[var(--color-spruce)]" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-[var(--color-text-main)] mb-2">教练的建议</h3>
                      <p className="text-sm text-[var(--color-text-muted)] whitespace-pre-wrap leading-relaxed">
                        {coachMessage}
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}

              {generatedExercises.length > 0 && (
                <button 
                  onClick={() => setShowGeneratedModal(true)}
                  className="w-full max-w-3xl py-4 border-2 border-dashed border-[var(--color-spruce)] text-[var(--color-spruce)] rounded-2xl flex items-center justify-center gap-2 text-sm font-medium hover:bg-[var(--color-spruce)] hover:text-[var(--color-bg-deep)] transition-colors"
                >
                  <Sparkles size={18} /> 查看刚才定制的练习
                </button>
              )}
            </motion.div>
          )}

          {activeTab === 'history' && (
            <motion.div
              key="history"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-6"
            >
              <h2 className="text-xl font-serif font-semibold text-[var(--color-text-main)]">打卡回顾</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {logs.slice().reverse().map(log => (
                  <div key={log.date} className="glass-card rounded-2xl p-5">
                    <div className="flex items-center justify-between mb-3 border-b border-white/10 pb-2">
                      <span className="font-serif font-semibold text-[var(--color-spruce)]">{log.date}</span>
                      <span className="text-xs font-medium px-2 py-1 bg-[var(--color-wood-light)] text-[var(--color-text-main)] rounded-full">
                        完成 {log.selectedExercises.filter(e => e.completed).length} 项
                      </span>
                    </div>
                    {log.feedback && (
                      <div className="mb-2">
                        <p className="text-[10px] font-bold text-[var(--color-spruce-dim)] uppercase">成就</p>
                        <p className="text-sm text-[var(--color-text-main)]">{log.feedback}</p>
                      </div>
                    )}
                    {log.adjustments && (
                      <div>
                        <p className="text-[10px] font-bold text-[var(--color-spruce-dim)] uppercase">调整</p>
                        <p className="text-sm text-[var(--color-text-main)]">{log.adjustments}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Generated Exercises Modal */}
      <AnimatePresence>
        {showGeneratedModal && generatedExercises.length > 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm"
          >
            <motion.div
              initial={{ scale: 0.95, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 20 }}
              className="relative w-full max-w-sm md:max-w-md bg-[var(--color-bg-deep)] rounded-3xl shadow-2xl border border-white/10 overflow-hidden flex flex-col max-h-[85vh]"
            >
              {/* Header */}
              <div className="flex justify-between items-center p-5 border-b border-white/5 shrink-0">
                <h3 className="font-serif font-semibold text-[var(--color-text-main)] flex items-center gap-2">
                  <Sparkles size={16} className="text-[var(--color-spruce)]" />
                  为你定制的微练习
                </h3>
                <button onClick={() => setShowGeneratedModal(false)} className="text-[var(--color-text-muted)] hover:text-white p-1">
                  <X size={20} />
                </button>
              </div>

              {/* Swipeable Content */}
              <div 
                className="flex overflow-x-auto snap-x snap-mandatory flex-1"
                style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
                onScroll={(e) => {
                  const scrollLeft = e.currentTarget.scrollLeft;
                  const width = e.currentTarget.clientWidth;
                  setActiveSlide(Math.round(scrollLeft / width));
                }}
              >
                <style>{`
                  .snap-x::-webkit-scrollbar { display: none; }
                `}</style>
                {generatedExercises.map((ex, index) => {
                  const isSelected = todayLog.selectedExercises.some(e => e.exerciseId === ex.id);
                  return (
                    <div key={ex.id} className="w-full flex-shrink-0 snap-center p-6 flex flex-col overflow-y-auto">
                      <div className="mb-4">
                        <span className="text-[10px] font-bold tracking-wider uppercase text-[var(--color-spruce)] bg-[var(--color-wood-light)] px-2 py-1 rounded-md">
                          {ex.categoryLabel}
                        </span>
                      </div>
                      <h4 className="font-serif text-xl font-semibold text-[var(--color-text-main)] mb-3">{ex.title}</h4>
                      <p className="text-sm text-[var(--color-text-muted)] mb-5 leading-relaxed">{ex.description}</p>
                      
                      <div className="bg-[var(--color-wood-dark)] p-4 rounded-xl border border-white/5 mb-6">
                        <p className="text-xs font-semibold text-[var(--color-spruce-dim)] mb-2">🎯 目标：</p>
                        <p className="text-sm text-[var(--color-text-main)]">{ex.target}</p>
                      </div>

                      <div className="mt-auto pt-4">
                        <button
                          onClick={() => isSelected ? removeExerciseFromToday(ex.id) : addExerciseToToday(ex.id)}
                          className={cn(
                            "w-full py-3.5 rounded-xl text-sm font-semibold flex items-center justify-center gap-2 transition-all",
                            isSelected 
                              ? "bg-green-900/30 text-green-400 border border-green-500/30" 
                              : "bg-[var(--color-spruce)] text-[var(--color-bg-deep)] hover:bg-opacity-90 shadow-lg shadow-[var(--color-spruce)]/20"
                          )}
                        >
                          {isSelected ? (
                            <><Check size={18} /> 已添加到今日练习</>
                          ) : (
                            <><Plus size={18} /> 添加到今日练习</>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
              
              {/* Pagination Dots */}
              <div className="flex justify-center gap-2 p-5 shrink-0 bg-gradient-to-t from-[var(--color-bg-deep)] to-transparent">
                {generatedExercises.map((_, idx) => (
                  <div 
                    key={idx} 
                    className={cn(
                      "w-1.5 h-1.5 rounded-full transition-all duration-300", 
                      activeSlide === idx ? "bg-[var(--color-spruce)] w-4" : "bg-white/20"
                    )} 
                  />
                ))}
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Timer Modal */}
      <AnimatePresence>
        {activeTimer && (
          <motion.div
            initial={{ opacity: 0, y: '100%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '100%' }}
            className="fixed inset-0 z-50 bg-[var(--color-bg-deep)] text-[var(--color-text-main)] flex flex-col"
            style={{
              backgroundImage: 'radial-gradient(circle at 50% 50%, rgba(61, 43, 31, 0.8) 0%, rgba(15, 12, 10, 1) 100%)'
            }}
          >
            <div className="max-w-3xl mx-auto w-full flex flex-col h-full">
              <div className="p-6 flex justify-between items-center shrink-0">
                <span className="text-sm font-medium tracking-widest uppercase text-[var(--color-spruce-dim)]">Focus Mode</span>
                <button onClick={closeTimer} className="p-2 bg-white/5 rounded-full hover:bg-white/10 transition-colors">
                  <X size={20} />
                </button>
              </div>
              
              <div className="flex-1 flex flex-col items-center justify-center px-8 text-center">
                <h2 className="text-2xl md:text-4xl font-serif mb-12 text-[var(--color-spruce)] drop-shadow-md">
                  {allExercises.find(e => e.id === activeTimer)?.title}
                </h2>
                
                <div className="text-8xl md:text-[9rem] font-light tracking-tighter tabular-nums mb-12 font-sans text-white drop-shadow-[0_0_15px_rgba(212,154,106,0.3)]">
                  {formatTime(timeLeft)}
                </div>
                
                <div className="flex gap-4">
                  <button
                    onClick={() => setTimerRunning(!timerRunning)}
                    className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-[var(--color-spruce)] text-[var(--color-bg-deep)] flex items-center justify-center hover:scale-105 transition-transform shadow-[0_0_20px_rgba(212,154,106,0.4)]"
                  >
                    {timerRunning ? <div className="w-5 h-5 md:w-6 md:h-6 bg-current rounded-sm" /> : <Play size={24} fill="currentColor" className="ml-1 md:w-8 md:h-8" />}
                  </button>
                </div>
              </div>
              
              <div className="p-8 md:p-12 bg-white/5 rounded-t-[40px] mt-auto backdrop-blur-xl border-t border-white/10 shrink-0">
                <h3 className="text-sm md:text-base font-semibold text-[var(--color-spruce)] mb-4 uppercase tracking-wider">执行步骤</h3>
                <ul className="space-y-3 md:space-y-4 text-sm md:text-base text-[var(--color-text-muted)] text-left">
                  {allExercises.find(e => e.id === activeTimer)?.steps.map((step, i) => (
                    <li key={i} className="flex gap-3">
                      <span className="text-[var(--color-spruce-dim)] font-mono">{i + 1}.</span>
                      <span>{step}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bottom Navigation (Mobile Only) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-[var(--color-wood-dark)]/80 backdrop-blur-xl border-t border-white/5 pb-safe z-40">
        <div className="flex justify-around items-center h-16 px-6">
          <button 
            onClick={() => setActiveTab('today')}
            className={cn(
              "flex flex-col items-center gap-1 transition-colors",
              activeTab === 'today' ? "text-[var(--color-spruce)]" : "text-[var(--color-text-muted)] hover:text-[var(--color-text-main)]"
            )}
          >
            <Clock size={20} />
            <span className="text-[10px] font-medium">今日</span>
          </button>
          <button 
            onClick={() => setActiveTab('library')}
            className={cn(
              "flex flex-col items-center gap-1 transition-colors",
              activeTab === 'library' ? "text-[var(--color-spruce)]" : "text-[var(--color-text-muted)] hover:text-[var(--color-text-main)]"
            )}
          >
            <BookOpen size={20} />
            <span className="text-[10px] font-medium">练习库</span>
          </button>
          <button 
            onClick={() => setActiveTab('coach')}
            className={cn(
              "flex flex-col items-center gap-1 transition-colors",
              activeTab === 'coach' ? "text-[var(--color-spruce)]" : "text-[var(--color-text-muted)] hover:text-[var(--color-text-main)]"
            )}
          >
            <Sparkles size={20} />
            <span className="text-[10px] font-medium">AI教练</span>
          </button>
          <button 
            onClick={() => setActiveTab('history')}
            className={cn(
              "flex flex-col items-center gap-1 transition-colors",
              activeTab === 'history' ? "text-[var(--color-spruce)]" : "text-[var(--color-text-muted)] hover:text-[var(--color-text-main)]"
            )}
          >
            <Calendar size={20} />
            <span className="text-[10px] font-medium">回顾</span>
          </button>
        </div>
      </nav>
    </div>
  );
}
