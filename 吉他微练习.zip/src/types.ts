export type Category = 'A' | 'B' | 'C' | 'D';

export interface Exercise {
  id: string;
  title: string;
  description: string;
  steps: string[];
  category: Category;
  categoryLabel: string;
  target: string;
}

export interface DailyLog {
  date: string; // YYYY-MM-DD
  selectedExercises: { exerciseId: string; completed: boolean }[];
  feedback: string;
  adjustments: string;
}
